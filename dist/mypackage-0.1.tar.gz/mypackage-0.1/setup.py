from setuptools import setup, find_packages

setup(
    name='mypackage',
    version='0.1',
    install_requires=['numpy'],
    author='Wanda Mbatha'
)